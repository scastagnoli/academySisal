package com.example.kafka.springbootkafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class kafkaRestController {

    @Autowired
    KafkaTemplate<String, User> kafkaTemplate;

    @GetMapping("/publish/{name}")
    public String postMessage(@PathVariable("name") final String name) {
        kafkaTemplate.send("nuoviOrdini", new User(name,"networking", 1000L));
        return "published succeffully";
    }
}
