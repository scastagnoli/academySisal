package com.sc.kafkaconsumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class KafkaOrderListener {
    @KafkaListener(topics="nuoviOrdini", groupId = "academy")
    public void listen(String order) {
        System.out.println("Ordine ricevuto: " + order);
    }
}
